#include <bits/stdc++.h>
using namespace std;

int main() {
    char operation;
    double num1, num2, result;

   
    cout << "Enter the first number: ";
    cin >> num1;

    cout << "Enter the second number: ";
    cin >> num2;

    cout << "Choose an operation (+, -, *, /): ";
    cin >> operation;

    switch (operation) {
        case '+':
            result = num1 + num2;
            std::cout << "Result: " << num1 << " + " << num2 << " = " << result <<endl;
            break;

        case '-':
            result = num1 - num2;
            std::cout << "Result: " << num1 << " - " << num2 << " = " << result <<endl;
            break;

        case '*':
            result = num1 * num2;
            std::cout << "Result: " << num1 << " * " << num2 << " = " << result <<endl;
            break;

        case '/':
            if (num2 != 0) {
                result = num1 / num2;
                cout << "Result: " << num1 << " / " << num2 << " = " << result <<endl;
            } else {
                std::cout << "Error! Division by zero is not allowed." <<endl;
            }
            break;

        default:
            std::cout << "Invalid operation. Please choose +, -, *, /." <<endl;
            break;
    }

    return 0;
}