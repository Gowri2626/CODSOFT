#include <bits/stdc++.h>
using namespace std;

void display(const vector<vector<char>>& board) {
    cout << "  1 2 3\n";
    for (int i = 0; i < 3; ++i) {
        cout << i + 1 << " ";
        for (int j = 0; j < 3; ++j) {
            cout << board[i][j] << " ";
        }
        cout << "\n";
    }
}

bool makeMove(vector<vector<char>>& board, char Player) {
    int row, col;
    cout << "Player " <<Player << ", enter your move (row and column): ";
    cin >> row >> col;

    --row;
    --col;

    if (row >= 0 && row < 3 && col >= 0 && col < 3 && board[row][col] == ' ') {
        board[row][col] =Player;
        return true;
    }

    return false;
}

bool Win(const vector<vector<char>>& board, char Player) {
    
    for (int i = 0; i < 3; ++i) {
        if (board[i][0] == Player && board[i][1] == Player && board[i][2] == Player) {
            return true;
        }
        if (board[0][i] == Player && board[1][i] == Player && board[2][i] == Player) {
            return true;
        }
    }
    if (board[0][0] == Player && board[1][1] == Player && board[2][2] == Player) {
        return true;
    }
    if (board[0][2] == Player && board[1][1] == Player){
        return true;
    }
    

    return false;
}

bool Draw(const vector<vector<char>>& board) {

    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            if (board[i][j] == ' ') {
                return false; 
            }
        }
    }
    return true; 
}

void switchPlayer(char& Player) {
    
    Player = (Player == 'X') ? 'O' : 'X';
}

bool playAgain() {
    char choice;
    cout << "Do you want to play again? (y/n): ";
    cin >> choice;
    return (choice == 'y' || choice == 'Y');
}

int main() {
    char Player = 'X';
    vector<vector<char>> board(3,vector<char>(3, ' '));

    do {
        display(board);

        if (!makeMove(board, Player)) {
            cout << "Invalid move. Try again.\n";
            continue;
        }

        if (Win(board, Player)) {
            display(board);
            cout << "Player " <<Player << " wins!\n";
        } else if (Draw(board)) {
            display(board);
            cout << "It's a draw!\n";
        } else {
            switchPlayer(Player);
        }

    } while (playAgain());
        
        cout << "Thanks for playing!\n";

    return 0;
}

